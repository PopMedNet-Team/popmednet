-- Change the using statment and the Bulk Import to point to correct Database
USE [Change_ME]
go
/******ICD 10 ESP Codes******/
INSERT INTO [dbo].[LookupLists]([ListId],[ListName],[Version])VALUES(18,'ICD 10 ESP Codes',null)
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'1','Certain infectious and parasitic diseases (A00-B99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'2','Neoplasms (C00-D49)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'3','Diseases of the blood and blood-forming organs and certain disorders involving the immune mechanism (D50-D89)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'4','Endocrine, nutritional and metabolic diseases (E00-E89)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'5','Mental, Behavioral and Neurodevelopmental disorders (F01-F99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'6','Diseases of the nervous system (G00-G99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'7','Diseases of the eye and adnexa (H00-H59)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'8','Diseases of the ear and mastoid process (H60-H95)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'9','Diseases of the circulatory system (I00-I99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'10','Diseases of the respiratory system (J00-J99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'11','Diseases of the digestive system (K00-K95)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'12','Diseases of the skin and subcutaneous tissue (L00-L99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'13','Diseases of the musculoskeletal system and connective tissue (M00-M99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'14','Diseases of the genitourinary system (N00-N99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'15','Pregnancy, childbirth and the puerperium (O00-O9A)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'16','Certain conditions originating in the perinatal period (P00-P96)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'17','Congenital malformations, deformations and chromosomal abnormalities (Q00-Q99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'18','Symptoms, signs and abnormal clinical and laboratory findings, not elsewhere classified  (R00-R99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'19','Injury, poisoning and certain other consequences of external causes (S00-T88)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'20','External causes of morbidity (V00-Y99)')
GO
INSERT INTO [dbo].[LookupListCategories]([ListId],[CategoryId],[CategoryName])VALUES(18,'21','Factors influencing health status and contact with health services (Z00-Z99)')
GO
BULK INSERT [Change_ME].dbo.[LookupListValues]
   FROM 'C:\publish\codes.csv'
   WITH 
      (
         FIELDTERMINATOR ='|'
      );
